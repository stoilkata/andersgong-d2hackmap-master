UnitAny* D2CLIENT_GetNextPlayer(UnitAny *pla)
{
	return pla ? pla->pNextPlayer : *p_D2CLIENT_PlayerUnitListHdr;
}

DWORD __declspec(naked) __fastcall D2CLIENT_InitAutomapLayer_STUB(DWORD nLayerNo)
{
	__asm {
		mov eax, ecx
		call D2CLIENT_InitAutomapLayer_I
		ret
	}
}

void __declspec(naked) __fastcall D2CLIENT_SetAutomapParty_STUB(DWORD flag)
{
	__asm {
		push esi
		mov esi, ecx
		call D2CLIENT_SetAutomapParty_I
		pop esi
		ret
	}
}

void __declspec(naked) __fastcall D2CLIENT_SetAutomapNames_STUB(DWORD flag)
{
	__asm {
		push esi
		mov esi, ecx
		call D2CLIENT_SetAutomapNames_I
		pop esi
		ret
	}
}

DWORD __declspec(naked) __fastcall D2CLIENT_GetMonsterTxt_STUB(DWORD monno)
{
	__asm {
		mov eax, ecx
		jmp D2CLIENT_GetMonsterTxt_I
	}
}

DWORD __declspec(naked) __fastcall D2CLIENT_TestPvpFlag_STUB(DWORD planum1, DWORD planum2, DWORD flagmask)
{
	__asm {
		push esi
		push [esp+8] // flagmask
		mov esi, edx
		mov edx, ecx
		call D2CLIENT_TestPvpFlag_I
		pop esi
		ret 4
	}
}

DWORD __declspec(naked) __fastcall D2CLIENT_GetUnitFromId_STUB(DWORD unitid, DWORD unittype)
{
	__asm
	{
		pop eax;
		push edx; // unittype
		push eax; // return address

		shl edx, 9;
		mov eax, p_D2CLIENT_pUnitTable;
		add edx, eax;
		mov eax, ecx; // unitid
		and eax, 0x7F;
		jmp D2CLIENT_GetUnitFromId_I;
	}
}

DWORD __declspec(naked) __fastcall D2CLIENT_GetInventoryId_STUB(UnitAny* pla, DWORD unitno, DWORD arg3)
{
	__asm {
	push    esi
	push    edi
	test    ecx, ecx
	jz      short loc_6FAB1952
	mov     eax, p_D2CLIENT_UnitListHdr
	mov		eax, [eax]
	mov     ecx, [ecx]UnitAny.nUnitId
	test    eax, eax
	jz      short loc_6FAB1952
	mov     esi, [esp+0x0c]

loc_6FAB1936:
	cmp     [eax+4], edx
	jnz     short loc_6FAB194B
	cmp     [eax+0Ch], ecx
	jnz     short loc_6FAB194B
	test    esi, esi

	jnz     short loc_6FAB195A
	mov     edi, [eax+20h]
	test    edi, edi
	jz      short loc_6FAB195A

loc_6FAB194B:
	mov     eax, [eax+30h]
	test    eax, eax
	jnz     short loc_6FAB1936

loc_6FAB1952:
	pop     edi
	or      eax, 0FFFFFFFFh
	pop     esi
	retn    4
loc_6FAB195A:
	mov     eax, [eax+8]
	pop     edi
	pop     esi
	retn    4
	}
}

DWORD __declspec(naked) __fastcall D2CLIENT_GetUiVar_STUB(DWORD varno)
{
	__asm {
		mov eax, ecx
		jmp D2CLIENT_GetUiVar_I
	}
}

// eax == this ptr
DWORD __declspec(naked) __fastcall D2WIN_DrawText2_STUB(LPWSTR lpText, int x, int y, DWORD u1, int nColor, DWORD u2)
{
	__asm {
		mov eax, ecx	// lpText
		pop ecx			// save return address
		push edx		// x
		push ecx		// push return address
		jmp D2WIN_DrawText2_I
	}
}

// eax == this ptr
DWORD __declspec(naked) __fastcall D2WIN_InitializeFontTable_STUB(LPSTR lpText, DWORD line, LPCSTR file)
{
	__asm {
		mov eax, ecx	// lpText
		pop ecx			// save return address
		push edx		// line
		push ecx		// push return address
		jmp D2WIN_InitializeFontTable_I
	}
}

// ecx == this ptr
DWORD __declspec(naked) __fastcall D2WIN_InitializeFont_STUB(LPSTR lpText, DWORD dwSize)
{
	__asm {
		pop eax			// save return address
		push edx		// dwSize
		push eax		// push return address
		jmp D2WIN_InitializeFont_I
	}
}

// esi == this ptr
DWORD __declspec(naked) __fastcall D2WIN_FontStuff_1_STUB(D2EditBox *hWnd)
{
	__asm {
		push esi
		mov esi, ecx
		call D2WIN_FontStuff_1_I
		pop esi
		ret
	}
}

// eax == this ptr
DWORD __declspec(naked) __fastcall D2WIN_FontStuff_2_STUB(D2EditBox *hWnd, DWORD bKeyCode)
{
	__asm {
		mov eax, ecx	// hWnd
		pop ecx			// save return address
		push edx		// bKeyCode
		push ecx		// push return address
		jmp D2WIN_FontStuff_2_I
	}
}
