Patch_t aKeepGameWindowPatchs[] = {
	// 0x4938: push SW_MINIMIZE; push ecx; call edi;
	{PatchFILL,   D2GFX_KeepD2WindowPatch1,   4, 1, -1}, // SW_MINIMIZE

	// 0x4917: push SW_MINIMIZE; push ecx; call edi;
//	{PatchFILL,   D2GFX_KeepD2WindowPatch2,   4, 1, -1}, // obsoleted in 1.11

	// 0x4978: push SW_HIDE; push edx; call ebp;
	{PatchFILL,   D2GFX_KeepD2WindowPatch3,   4, 1, -1}, // SW_HIDE
};

#if 0 // not use any longer since use new method to remove all hackmap created cell files upon unloading
static BYTE aCellAssertPatch1[] = {0x33,0xc0, 0x5f, 0xeb,0x41}; //xor eax,eax; pop edi; jmp +0x41
static BYTE aCellAssertPatch2[] = {0xeb, 0x03}; //jmp +0x03
Patch_t aKillCellAssertPatchs[] = {
	{PatchDATA,   DLLOFFSET(D2CMP, DLLBASE_D2CMP+0x2587),   (DWORD)aCellAssertPatch1, sizeof(aCellAssertPatch1), -1}, // KillCellAssert
	{PatchDATA,   DLLOFFSET(D2CMP, DLLBASE_D2CMP+0xBD7A),   (DWORD)aCellAssertPatch2, sizeof(aCellAssertPatch2), -1}, // KillCellAssert
};
#endif

Patch_t aPacketRecvPatchs[] = {
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xBDFCF),   (DWORD)GamePacketReceivedInterceptPatch_ASM, 6, -1},
};

Patch_t aD2Patchs2[] = {
	{PatchCALL,   DLLOFFSET(D2MULTI, DLLBASE_D2MULTI+0x148EB),   (DWORD)NextGameNamePatch, 5, -1},
	{PatchCALL,   DLLOFFSET(D2MULTI, DLLBASE_D2MULTI+0x14926),   (DWORD)NextGamePasswordPatch, 5, -1},

	{PatchCALL,   DLLOFFSET(D2MULTI, DLLBASE_D2MULTI+0x14C09),   (DWORD)NextGameNamePatch, 5, -1},
	{PatchCALL,   DLLOFFSET(D2MULTI, DLLBASE_D2MULTI+0x14C44),   (DWORD)NextGamePasswordPatch, 5, -1},
};

Patch_t aD2LocalePatchs2[] = {
	// Locale
	{PatchCALL,   DLLOFFSET(D2MULTI, DLLBASE_D2MULTI+0xF8EB),   (DWORD)EnterChatPatch, 5, -1},
};

Patch_t aD2Patchs[] = {
	{PatchFILL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x52A64),   INST_NOP, 2, -1}, //floors inside
	{PatchFILL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x52AAA),   INST_NOP, 2, -1}, //walls inside
	{PatchFILL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x521D1),   INST_NOP, 6, -1}, //shrine distance

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x51410),   (DWORD)SaveAutomapLayerToFilePatch_ASM, 5, 0xffffffff},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x52310),   (DWORD)LoadAutomapLayerFromFilePatch_ASM, 6, 0xffffffff},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x51624),   (DWORD)OverrideShrinePatch_ASM, 7, 0xffffffff},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x52223),   (DWORD)AddShrinePatch_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x506AA),   (DWORD)DrawAutomapCellPatch, 5, -1},
	{PatchJMP,    DLLOFFSET(D2COMMON, DLLBASE_D2COMMON+0x1E216),   (DWORD)WeatherPatch_ASM, 5, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x35ED7),	(DWORD)LightingPatch_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x32BB2),   (DWORD)ShakeScreenPatch, 5, -1},
	{PatchFILL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x9349F),   INST_NOP, 2, 0xffffffff}, //force perspective shake
	{PatchFILL,	  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x1BDFF),   INST_NOP, 2, -1}, //force get shake
	{PatchFILL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x933C6),   INST_NOP, 15, -1}, //kill add shake
	{PatchFILL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x933D5),   INST_NOP, 2, -1}, //kill add shake, part 2
	{PatchFILL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x4FE60),   INST_NOP, 0x37, 0xffffffff}, //kill automap scroll, wipe out 4 adjustments
	{PatchCALL,   DLLOFFSET(D2WIN,    DLLBASE_D2WIN+0xF1A8),   (DWORD)LifeBarPatch_ASM, 6, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x76B66),   (DWORD)ItemNamePatch_ASM, 6, -1},
	{PatchVALUE,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x6324F),   0xe990, 2, -1}, //kill ground gold name
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x78C83),   (DWORD)OpenCubeStringPatch_ASM, 5, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x54ED3),   (DWORD)InfravisionPatch_ASM, 0x7, -1}, // 5 BYTES is enough, but 7 for not disturbing orignial instruction interpretation

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x51BFD),   (DWORD)HostilePlayerColor_ASM, 6, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x5200C),   (DWORD)MonsterBlobNamePatch_ASM, 5, -1},
	{PatchJMP,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x51B28),   (DWORD)MonsterBlobColPatch_ASM, 5, -1},
	
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x51FD3),   (DWORD)DrawObjectBlobPatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x5214B),   (DWORD)DrawPlayerBlobPatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x51FE9),   (DWORD)DrawMonsterBlobPatch_ASM, 5, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x51F64),   (DWORD)DrawItemBlobPatch_ASM, 6, -1},
	{PatchCALL2,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x50EA8),   (DWORD)DrawPlayerBlobPatch2_ASM, 0x3B, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x510E6),   (DWORD)RoomPatch_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x8279E),   (DWORD)MonsterDeathPatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x8185B),   (DWORD)MonsterDescCommaPatch1_ASM, 5, 0xffffff},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x81945),   (DWORD)MonsterDescCommaPatch2_ASM, 5, 0xffffff},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x63B01),   (DWORD)MonsterDescCommaPatch3_ASM, 6, 0xffffff},
	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0xDE30),   (DWORD)MonsterLifebarNamePatch_ASM, 6, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x79B72),   (DWORD)ViewInventoryPatch1_ASM, 6, -1}, //draw equip items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x7EBC5),   (DWORD)GetViewingInventoryPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x79244),   (DWORD)ViewInventoryPatch2_ASM, 6, -1}, //desc item
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x7826F),   (DWORD)ViewInventoryPatch3_ASM, 5, -1}, //test has item
	
	// stats, intercept all pPlayerUnit or GetPlayerUnit() to return our desired unit
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x89326),   (DWORD)GetViewingStatsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x89BE3),   (DWORD)GetViewingStatsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x3DFC3),   (DWORD)GetViewingStatsPlayerPatch3_ASM, 6, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x89023),   (DWORD)GetViewingStatsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x88A04),   (DWORD)GetViewingStatsPlayerPatch4_ASM, 6, -1}, //draw inv items

#if 0
	// TO BE FIXED
	//skill, below offsets are all for 1.10, fix up if needed
/*	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x76C07),   (DWORD)GetViewingSkillsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x763B7),   (DWORD)GetViewingSkillsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x76416),   (DWORD)GetViewingSkillsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x76A57),   (DWORD)GetViewingSkillsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x768AF),   (DWORD)GetViewingSkillsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x76967),   (DWORD)GetViewingSkillsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x76981),   (DWORD)GetViewingSkillsPlayer, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x76A08),   (DWORD)GetViewingSkillsPlayer, 5, -1}, //draw inv items

	// pet
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x4D5E8),   (DWORD)GetViewingPet, 5, -1}, //draw inv items
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x4D317),   (DWORD)GetViewingPet, 5, -1}, //draw inv items
*/	// end
#endif

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x7D650),   (DWORD)ViewInventoryPatch4_ASM, 5, -1}, //test has item
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x77C50),   (DWORD)SocketViewtablePatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x77BE2),   (DWORD)SocketViewtablePatch2_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x222FD),   (DWORD)ItemBasicStatPatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x1FF65),   (DWORD)OutTownSelectPatch1_ASM, 6, -1},
	{PatchJMP,	  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x52B9E),   (DWORD)GameTimePatch, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xA8DC9),   (DWORD)CowLevelQuestPatch_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x7D6A4),   (DWORD)SocketProtectPatch1_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x7B8BB),   (DWORD)SocketProtectPatch2_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x4CFD1),   (DWORD)OutTownSelectPatch2_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x4D07E),   (DWORD)OutTownSelectPatch3_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x63EBA),   (DWORD)PermShowItemsPatch_ASM, 6, 0xffffffff},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x66D5E),   (DWORD)PermShowItemsPatch_ASM, 6, 0xffffff},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x4D233),   (DWORD)PermShowItemsPatch2_ASM, 6, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xC2E2C),   (DWORD)CheckSpecialUiVarsPatch_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x148BD),   (DWORD)CheckUiVar_11_Patch_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x91D9C),   (DWORD)InputLinePatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x914AB),   (DWORD)InputLinePatch2_ASM, 5, -1},
	{PatchVALUE,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x24605), 0x2EB58, 3, -1},
	{PatchVALUE,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x24585), 0x2EB58, 3, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x32B40),   (DWORD)GameLoopPatch_ASM, 7, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x33883),   (DWORD)GameEndPatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x66EC5),   (DWORD)KeydownPatch_ASM, 7, -1},
	{PatchVALUE,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x918B7), (DWORD)"<KittyNet>: Correct usage is: %s", 4, 0xffff},
	{PatchVALUE,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x916CF), (DWORD)"<KittyNet>: Correct usage is: %s (name) (message)", 4, 0xffff},
	
	{PatchJMP,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x8A0BA),   (DWORD)ViewPlayerStatPatch_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xB5DF3),   (DWORD)PermShowOrbPatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xB5EDB),   (DWORD)PermShowOrbPatch2_ASM, 0x0B, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xB5EE6),   (DWORD)PermShowOrbPatch3_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xB6D1B),   (DWORD)GameTimeClockPatch_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xB6B8F),   (DWORD)GameTimeClockPatch2_ASM, 6, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x167D8),   (DWORD)MessageLogPatch1_ASM, 5, -1},
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x1654F),   (DWORD)MessageLogPatch2_ASM, 5, -1},

	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x94704),   (DWORD)PassingActBugFixPatch_ASM, 9, -1}, // bugfix for d2loader
#if 0
	// in 1.11 the code will be called twice, need to check if my change is ok
	{PatchFILL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0x822A), INST_JMPR, 1, -1}, // copy&paste bugfix, for 1.11
	// 0x33, 0x4A for detection request?
#endif

	// extrawork dll protection
	{PatchCALL,   DLLOFFSET(BNCLIENT, DLLBASE_BNCLIENT+0xDE41),   (DWORD)ExtraWorkPatch_ASM, 6, -1}, // Extra Work Dll
	{PatchCALL,   DLLOFFSET(BNCLIENT, DLLBASE_BNCLIENT+0xCC7A),   (DWORD)VersionCheckingPatch_ASM, 6, -1}, // Version Check Dll

	// right click swap
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x327F0),   (DWORD)RButtonUpHandlerPatch_ASM, 5, -1},

#if 0
	// test warden only, nerver use this in a release version
	{PatchVALUE,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x33771), 0x51EB, 2, -1},
#endif
	{PatchCALL,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x39E96), (DWORD)InitWardenModPatch_ASM, 5, -1},
	{PatchCALL,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x39FAF), (DWORD)CallWardenModPatch_ASM, 5, -1},
//	{PatchCALL,  DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x3A083), (DWORD)DecodeWardenMethodsPatch_ASM, 5, -1},
};

Patch_t aD2LocalePatchs[] = {
	{PatchFILL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x14835), INST_JMPR, 1, -1}, // in game
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x91E93),   (DWORD)D2LocaleGameChat, 5, -1}, // in game chat
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x14BFE),   (DWORD)DrawTextInGameWithMyFont, 5, -1}, // Main InGame Screen Text
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x91535),   (DWORD)DrawTextWithMyFont, 5, -1}, // Chat Input Box
	{PatchCALL,   DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0x83854),   (DWORD)DrawTextInGameWithMyFont, 5, -1}, // Log Message List Box
	{PatchCALL,   DLLOFFSET(BNCLIENT, DLLBASE_BNCLIENT+0xB2EC),   (DWORD)D2MultiByteFixPatch_ASM, 6, -1}, // for /w *acc msg text
	
	{PatchFILL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0xF629), INST_NOP, 2, -1},
	{PatchFILL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0xF638), INST_JMPR, 1, -1}, // in channel
	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0xF50A),   (DWORD)D2WIN_DrawText2Patch, 5, -1},
	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0xF0BC),   (DWORD)D2Win_InitializeFontTablePatch, 5, -1},
	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0xF57B),   (DWORD)D2Win_InitializeFontPatch, 5, -1},
	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0xF81A),   (DWORD)D2Win_InitializeFontPatch, 5, -1},
	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0xDDC0),   (DWORD)IsPritableCharacterPatch_ASM, 8, -1}, // for traditionnal chinese
	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0x138E0),   (DWORD)ChannelEnterCharPatch, 5, -1},

	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0x16AAF),   (DWORD)DrawTextInChannelWithMyFontPatch_ASM, 5, -1}, // Town Hall Channel
	{PatchCALL,   DLLOFFSET(D2WIN, DLLBASE_D2WIN+0x11295),   (DWORD)DrawTextInChannelWithMyFontPatch2_ASM, 5, -1}, // Channel Input Box
	
	{PatchJMP,   DLLOFFSET(D2LANG, DLLBASE_D2LANG+0x8C40),   (DWORD)D2Lang_Unicode2Win, 5, -1},
	{PatchJMP,   DLLOFFSET(D2LANG, DLLBASE_D2LANG+0x8C70),   (DWORD)D2Lang_Win2Unicode, 5, -1},
	{PatchJMP,   DLLOFFSET(D2LANG, DLLBASE_D2LANG+0x8CC0),   (DWORD)D2Lang_Utf82Unicode, 5, -1},
};

#define RECVCMD_OFFSET(n) DLLOFFSET(D2CLIENT, DLLBASE_D2CLIENT+0xDBC28+8+12*(n))
Patch_t aD2PacketHandlerPatchs[] = {
	//!!CAUTION: the order must not be changed.
	{PatchVALUE, RECVCMD_OFFSET(0xAE), (DWORD)RecvCommand_AE_Patch_ASM, 4, 0xffff},
};

PatchItem_t aD2PatchItems[] = {
	{aD2Patchs, ARRAYSIZE(aD2Patchs)},
	// this is for capturing packet, debug only
//	{aD2PacketHandlerPatchs, ARRAYSIZE(aD2PacketHandlerPatchs)},
	{aKeepGameWindowPatchs, ARRAYSIZE(aKeepGameWindowPatchs), 1},
	{aPacketRecvPatchs, ARRAYSIZE(aPacketRecvPatchs), 1},

//	{aD2Patchs2, ARRAYSIZE(aD2Patchs2), 1},
//	{aD2LocalePatchs2, ARRAYSIZE(aD2LocalePatchs2), 1},
//	{aKillCellAssertPatchs, ARRAYSIZE(aKillCellAssertPatchs)},
};
