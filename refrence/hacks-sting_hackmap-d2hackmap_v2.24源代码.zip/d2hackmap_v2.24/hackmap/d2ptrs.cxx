typedef HMODULE (__stdcall *LoadLibraryA_t)(LPCSTR);
#define pD2PtrsListStart p_D2CLIENT_pDrlgAct

D2VARPTR(D2CLIENT, pDrlgAct, DrlgAct *, DLLBASE_D2CLIENT+0x11C2D0)
D2FUNCPTR(D2CLIENT, RecvCommand07, void __fastcall, (BYTE *cmdbuf), DLLBASE_D2CLIENT+0xBD6C0)
D2FUNCPTR(D2CLIENT, RecvCommand08, void __fastcall, (BYTE *cmdbuf), DLLBASE_D2CLIENT+0xBD650)
D2FUNCPTR(D2COMMON, InitDrlgLevel, void __stdcall, (DrlgLevel *drlglevel), -10741)
D2FUNCPTR(D2COMMON, GetDrlgLevel, DrlgLevel * __fastcall, (DrlgMisc *drlgmisc, DWORD levelno), -11058)
D2FUNCPTR(D2COMMON, GetDrlgLayer, AutomapLayer2* __fastcall, (DWORD levelno), -10641)
D2FUNCPTR(D2CLIENT, InitAutomapLayer_I, AutomapLayer* __fastcall, (DWORD nLayerNo), DLLBASE_D2CLIENT+0x52BB0)
D2FUNCPTR(D2CLIENT, RevealAutomapRoom, void __stdcall, (DrlgRoom1 *room1, DWORD clipflag, AutomapLayer *layer), DLLBASE_D2CLIENT+0x52A20)
D2VARPTR(D2CLIENT, pAutomapLayerListHdr, AutomapLayer *, DLLBASE_D2CLIENT+0x11C150)
D2VARPTR(D2CLIENT, pAutomapCellListHdr, AutomapCell *, DLLBASE_D2CLIENT+0x11C144)

D2VARPTR(D2CLIENT, pAutomapLayer, AutomapLayer *, DLLBASE_D2CLIENT+0x11C154)
D2VARPTR(D2CLIENT, PlayerUnit, UnitAny *, DLLBASE_D2CLIENT+0x11C1E0)
D2VARPTR(D2CLIENT, PlayerUnitListHdr, UnitAny *, DLLBASE_D2CLIENT+0x11C33C)
D2FUNCPTR(D2CLIENT, PrintGameStringAtTopLeft, void __stdcall, (wchar_t* text, int arg2), DLLBASE_D2CLIENT+0x16780)
D2FUNCPTR(D2CLIENT, PrintGameStringAtBottomLeft, void __stdcall, (wchar_t* text, int arg2), DLLBASE_D2CLIENT+0x16540)
D2VARPTR(D2NET, Socket, DWORD, DLLBASE_D2NET+0xB24C)
D2VARPTR(D2CLIENT, pszServerIp, char, DLLBASE_D2CLIENT+0xF1A20)
D2VARPTR(D2CLIENT, ptAutomap, POINT, DLLBASE_D2CLIENT+0x11C178)
D2VARPTR(D2CLIENT, ptOffset, POINT, DLLBASE_D2CLIENT+0x11C188)
D2VARPTR(D2CLIENT, nPtDivisor, int, DLLBASE_D2CLIENT+0xF13F0)
D2VARPTR(D2CLIENT, xMapShake, int, DLLBASE_D2CLIENT+0x11BAFC)
D2VARPTR(D2CLIENT, yMapShake, int, DLLBASE_D2CLIENT+0xFD944)
D2VARPTR(D2CLIENT, yPosition, int, DLLBASE_D2CLIENT+0x11C1AC)
D2FUNCPTR(D2CLIENT, GetAutomapSize, DWORD __stdcall, (), DLLBASE_D2CLIENT+0x4F520)
D2FUNCPTR(D2CLIENT, NewAutomapCell, AutomapCell * __fastcall, (), DLLBASE_D2CLIENT+0x4FB10)
D2FUNCPTR(D2CLIENT, AddAutomapCell, void __fastcall, (AutomapCell *cell, AutomapCell **node), DLLBASE_D2CLIENT+0x515F0)

// esi == flag
D2FUNCPTR(D2CLIENT, SetAutomapParty_I, void __fastcall, (DWORD flag), DLLBASE_D2CLIENT+0x4FD30)

// esi == flag
D2FUNCPTR(D2CLIENT, SetAutomapNames_I, void __fastcall, (DWORD flag), DLLBASE_D2CLIENT+0x4FD00)

// eax == monno
D2FUNCPTR(D2CLIENT, GetMonsterTxt_I, MonsterTxt * __fastcall, (DWORD monno), DLLBASE_D2CLIENT+0x11B0)
D2ASMPTR(D2CLIENT, GetMonsterTxt_I2, DLLBASE_D2CLIENT+0x1630)

// edx == planum1, esi == planum2
D2FUNCPTR(D2CLIENT, TestPvpFlag_I, DWORD __fastcall, (DWORD planum1, DWORD planum2, DWORD flagmask), DLLBASE_D2CLIENT+0x1A980)
D2FUNCPTR(D2CLIENT, GetMonsterOwner, DWORD __fastcall, (DWORD monnum), DLLBASE_D2CLIENT+0x56390)
D2FUNCPTR(D2CLIENT, GetSelectedUnit, UnitAny * __stdcall, (), DLLBASE_D2CLIENT+0x2F950)
D2VARPTR(D2CLIENT, pUnitTable, POINT, DLLBASE_D2CLIENT+0x10B470)
D2ASMPTR(D2CLIENT, GetUnitFromId_I, DLLBASE_D2CLIENT+0x4B410)

//D2FUNCPTR(D2CLIENT, GetInventoryId, DWORD __fastcall, (UnitAny* pla, DWORD unitno, DWORD arg3), DLLBASE_D2CLIENT+0x11920) // obsoleted in 1.11, use below
D2VARPTR(D2CLIENT, UnitListHdr, UnitAny*, DLLBASE_D2CLIENT+0x11C128)

D2FUNCPTR(D2CLIENT, GetUnitNoFromId, DWORD __fastcall, (DWORD unitid), DLLBASE_D2CLIENT+0x56360)
D2FUNCPTR(D2CLIENT, SocketProtect_ORIG, void __stdcall, (UnitAny *unit, DWORD arg2), DLLBASE_D2CLIENT+0x2BCA0)
D2FUNCPTR(D2CLIENT, GetPlayerXOffest, int __stdcall, (), DLLBASE_D2CLIENT+0x1BBE0)
D2FUNCPTR(D2CLIENT, GetPlayerYOffset, int __stdcall, (), DLLBASE_D2CLIENT+0x1BBF0)
D2VARPTR(D2CLIENT, fExitAppFlag, DWORD, DLLBASE_D2CLIENT+0xF18C0)

D2FUNCPTR(D2CLIENT, SetUiVar, DWORD __fastcall, (DWORD varno, DWORD howset, DWORD unknown1), DLLBASE_D2CLIENT+0x65690)
// eax == varno
D2FUNCPTR(D2CLIENT, GetUiVar_I, DWORD __fastcall, (DWORD varno), DLLBASE_D2CLIENT+0x61380)
D2VARPTR(D2CLIENT, pInSocketablePatch, UnitAny *, DLLBASE_D2CLIENT+0x11BBDC)
D2VARPTR(D2CLIENT, pMonsterNameLifePatch1, UnitAny, DLLBASE_D2CLIENT+0xECD04)
D2VARPTR(D2CLIENT, pMonsterNameLifePatch2, UnitAny, DLLBASE_D2CLIENT+0xECD0C)
D2FUNCPTR(D2CLIENT, GetQuestInfo, void* __stdcall, (), DLLBASE_D2CLIENT+0x56BD0)
D2FUNCPTR(D2CLIENT, GetDifficulty, BYTE __stdcall, (), DLLBASE_D2CLIENT+0x30070)
D2VARPTR(D2CLIENT, szLastChatMessage, wchar_t, DLLBASE_D2CLIENT+0x11D590)
D2VARPTR(D2CLIENT, nTextLength, int, DLLBASE_D2CLIENT+0x11BB30)
D2FUNCPTR(D2CLIENT, CalcShake, void __stdcall, (DWORD *xpos, DWORD *ypos), DLLBASE_D2CLIENT+0x93300)
D2ASMPTR(D2CLIENT, GetPlayerStat, DLLBASE_D2CLIENT+0x89B40)
D2ASMPTR(D2CLIENT, GetPlayerStat_END, DLLBASE_D2CLIENT+0x89FBF)
D2ASMPTR(D2CLIENT, GetPlayerStatJmpTbl, DLLBASE_D2CLIENT+0x89B87)
D2ASMPTR(D2CLIENT, GetPlayerStatJmpTbl2, DLLBASE_D2CLIENT+0x89CD9)
D2ASMPTR(D2CLIENT, OverrideShrinePatch_ORIG, DLLBASE_D2CLIENT+0x108870)
D2FUNCPTR(D2CLIENT, GetGameInfo, GameStructInfo* __stdcall, (), DLLBASE_D2CLIENT+0x36AA0)
//D2FUNCPTR(D2CLIENT, LButtonDownHandler, void __stdcall, (D2MSG * ptMsg), DLLBASE_D2CLIENT+0x896B0) // 1.11
D2FUNCPTR(D2CLIENT, RButtonUpHandler, void __stdcall, (D2MSG * ptMsg), DLLBASE_D2CLIENT+0x327F0);
D2FUNCPTR(D2CLIENT, GetUnknownFlag, DWORD __fastcall, (), DLLBASE_D2CLIENT+0x30080);
D2VARPTR(D2CLIENT, UnkU3, DWORD, DLLBASE_D2CLIENT+0xECD14);
D2VARPTR(D2CLIENT, UnkU4, DWORD, DLLBASE_D2CLIENT+0xECD18);
D2VARPTR(D2CLIENT, UnkU6, DWORD, DLLBASE_D2CLIENT+0x11C2B8);
D2VARPTR(D2CLIENT, nQuestPage, int, DLLBASE_D2CLIENT+0x11D535)
D2VARPTR(D2CLIENT, fAutomapOn, DWORD, DLLBASE_D2CLIENT+0x1040E8)
D2ASMPTR(D2CLIENT, ItemNamePatch_ORIG, DLLBASE_D2CLIENT+0x73240)
D2VARPTR(D2CLIENT, UiVarArray, DWORD, DLLBASE_D2CLIENT+0x1040C0); // not use but just keep in mind
D2VARPTR(D2CLIENT, PacketHandlerTable, DWORD, DLLBASE_D2CLIENT+0xDBC28 ); // not use but just keep in mind

D2FUNCPTR(D2CLIENT, DecodeWardenMethods_I, void __fastcall, (DWORD size, LPBYTE code, LPBYTE hashkey), DLLBASE_D2CLIENT+0x39C80)
D2VARPTR(D2CLIENT, pWardenInterface, LPBYTE, DLLBASE_D2CLIENT+0x11C254)
D2FUNCPTR(D2CLIENT, InitWardenInterface_I, void __fastcall, (LPBYTE rawcode, LPBYTE pInterface), DLLBASE_D2CLIENT+0xC3670)

// D2COMMON ptrs
D2FUNCPTR(D2COMMON, GetObjectTxt, ObjectTxt * __stdcall, (DWORD objno), -10916)
D2FUNCPTR(D2COMMON, GetItemTxt, ItemTxt * __stdcall, (DWORD itemno), -10262)
D2FUNCPTR(D2COMMON, GetLevelTxt, LevelTxt * __stdcall, (DWORD levelno), -10445)
D2FUNCPTR(D2COMMON, GetSuperuniqueTxt, SuperuniqueTxt * __stdcall, (DWORD monno), -10953)
D2FUNCPTR(D2COMMON, GetUnitStat, int __stdcall, (UnitAny *unit, DWORD statno, DWORD unk), -10061)
D2FUNCPTR(D2COMMON, GetUnitState, int __stdcall, (UnitAny *unit, DWORD stateno), -10604)
D2FUNCPTR(D2COMMON, GetItemFlag, DWORD __stdcall, (UnitAny *item, DWORD flagmask, DWORD lineno, char *filename), -10303)
D2FUNCPTR(D2COMMON, GetFunUnk_5, DWORD __stdcall, (DWORD nLevelNo), -11100)
D2FUNCPTR(D2COMMON, TestFunUnk_6, DWORD __stdcall, (UnitAny *unit1, UnitAny *unit2, DWORD arg3), -10123)
D2FUNCPTR(D2COMMON, GetQuestFlag, int __stdcall, (void *questinfo, DWORD quest, DWORD flag), -10753)
D2FUNCPTR(D2COMMON, GetItemFromInventory, DWORD __stdcall, (UnitInventory* inv), -10535)
D2FUNCPTR(D2COMMON, GetNextItemFromInventory, DWORD __stdcall, (DWORD no), -11140)
D2FUNCPTR(D2COMMON, GetUnitFromItem, UnitAny * __stdcall, (DWORD arg1), -10748)
D2FUNCPTR(D2COMMON, GetCursorItem, UnitAny * __stdcall, (UnitInventory * ptInventory), -10914)
D2FUNCPTR(D2COMMON, GetItemValue, int __stdcall, (UnitAny * player, UnitAny * item, DWORD difficulty, void* questinfo, int value, DWORD flag), -10511)
D2ASMPTR(D2COMMON, GetLevelIdFromRoom, -11021)
D2FUNCPTR(D2COMMON, 10409, DWORD __stdcall, (UnitAny * pla, int invlocation, DWORD unk), -10301);
D2FUNCPTR(D2COMMON, 10247, int __stdcall, (UnitInventory* inventory, UnitAny *item, DWORD u3, DWORD u4, DWORD u5, int* u6, int* ItemCount, int invlocation), -10448);
D2FUNCPTR(D2COMMON, GetMonsterColorIndex, int __stdcall, (UnitAny *mon, int no), -10924)
D2VARPTR(D2COMMON, nWeaponsTxt, int, DLLBASE_D2COMMON+0x9FB1C)
D2VARPTR(D2COMMON, nArmorTxt, int, DLLBASE_D2COMMON+0x9FB24)
D2VARPTR(D2COMMON, nMiscTxt, int, DLLBASE_D2COMMON+0x9FB2C) // unkown var_1
D2FUNCPTR(D2COMMON, GetTreasureClasses, TreasureClass * __stdcall, (DWORD tcno, DWORD lvlno), -10402)

// D2WIN ptrs
D2FUNCPTR(D2WIN, SetTextSize, DWORD __fastcall, (DWORD size), -10170)
D2FUNCPTR(D2WIN, GetTextWidthFileNo, DWORD __fastcall, (wchar_t *str, DWORD* width, DWORD* fileno), -10183)
D2FUNCPTR(D2WIN, DrawText, void __fastcall, (wchar_t *str, int xpos, int ypos, DWORD col, DWORD unknown), -10064)
D2FUNCPTR(D2WIN, ORD_27D7, DWORD __fastcall, (LPCWSTR lpText, DWORD u1, DWORD u2), -10034)
D2FUNCPTR(D2WIN, CreateEditBox, D2EditBox* __fastcall, (DWORD style, int ypos, int xpos, DWORD arg4, DWORD arg5, DWORD arg6, DWORD arg7, DWORD arg8, DWORD arg9, DWORD size, void* buf), -10112)
D2FUNCPTR(D2WIN, DestroyEditBox, DWORD __fastcall, (D2EditBox* box), -10085)
D2FUNCPTR(D2WIN, GetEditBoxText, wchar_t* __fastcall, (D2EditBox* box), -10055)
D2FUNCPTR(D2WIN, AddEditBoxChar, DWORD __fastcall, (D2EditBox* box, BYTE keycode), -10084)
D2FUNCPTR(D2WIN, SetEditBoxText, void* __fastcall, (D2EditBox* box, wchar_t* txt), -10149)
D2FUNCPTR(D2WIN, SetEditBoxProc, void __fastcall, (D2EditBox* box, BOOL (__stdcall *FunCallBack)(D2EditBox*,DWORD,DWORD)), -10179)
D2FUNCPTR(D2WIN, SelectEditBoxText, void __fastcall, (D2EditBox* box), -10047)
D2VARPTR(D2WIN, pFocusedControl, D2EditBox*, DLLBASE_D2WIN+0x20498)

// D2GFX ptrs
D2FUNCPTR(D2GFX, DrawAutomapCell, void __stdcall, (CellContext *context, DWORD xpos, DWORD ypos, RECT *cliprect, DWORD bright), -10005)
D2FUNCPTR(D2GFX, DrawAutomapCell2, void __stdcall, (CellContext *context, DWORD xpos, DWORD ypos, DWORD bright2, DWORD bright, BYTE *coltab), -10044)
D2FUNCPTR(D2GFX, DrawLine, void __stdcall, (int x1, int y1, int x2, int y2, DWORD col, DWORD unknown), -10001)
D2FUNCPTR(D2GFX, GetScreenSize, DWORD __stdcall, (), -10063)
D2FUNCPTR(D2GFX, GetHwnd, HWND __stdcall, (), -10022)

// D2CMP ptrs
D2FUNCPTR(D2CMP, InitCellFile, void __stdcall, (void *cellfile, CellFile **outptr, char *srcfile, DWORD lineno, DWORD filever, char *filename), -10036)
D2FUNCPTR(D2CMP, DeleteCellFile, void __stdcall, (CellFile *cellfile), -10014)

// D2LANG ptrs
D2FUNCPTR(D2LANG, GetLocaleText, wchar_t* __fastcall, (WORD nLocaleTxtNo), -10000)

// D2NET ptrs
D2FUNCPTR(D2NET, SendPacket, void __stdcall, (size_t len, DWORD arg1, BYTE* buf), -10020)

// BNCLIENT ptrs
D2VARPTR(BNCLIENT, fnLoadLibraryA, LoadLibraryA_t, DLLBASE_BNCLIENT+0x18180)

// below to be fixed...
//D2FUNCPTR(D2CLIENT, GetPlayerUnit, UnitAny * __stdcall, (), DLLBASE_D2CLIENT+0x883D0) // obsoleted in 1.11
//D2FUNCPTR(D2CLIENT, GetNextPlayer, UnitAny * __fastcall, (UnitAny* pla), DLLBASE_D2CLIENT+0xF5B0) // obsoleted in 1.11, use pla->pNextPlayer instead
//D2ASMPTR(D2CLIENT, SocketProtect_ORIG, DLLBASE_D2CLIENT+0xB14E0) // obsoleted
// the following three functions should be found
//D2FUNCPTR(D2CLIENT, RightClickInventoryItem, int __fastcall, (UnitAny * pla, UnitInventory * i, int x, int y, int invlocation), DLLBASE_D2CLIENT+0x48C60); 
//D2FUNCPTR(D2CLIENT, LeftClickInventoryItem, int __fastcall, (UnitAny * pla, UnitInventory * i, int x, int y, int clicktype, DWORD address, int invlocation), DLLBASE_D2CLIENT+0x475C0);
//D2FUNCPTR(D2CLIENT, MouseClick, int __fastcall, (int ClickType, unsigned short MouseX, unsigned short MouseY, BYTE ClickFlag), DLLBASE_D2CLIENT+0xA9920);

// keep window
D2ASMPTR(D2GFX, KeepD2WindowPatch1, DLLBASE_D2GFX+0x8381) // SW_MINIMIZE
D2ASMPTR(D2GFX, KeepD2WindowPatch3, DLLBASE_D2GFX+0x7EA7) // SW_HIDE

// Locale
// 1.11 ptrs
D2FUNCPTR(D2WIN, ORD_2743, DWORD __fastcall, (DWORD u1, LPCWSTR lpText, DWORD u2, DWORD u3, DWORD u4), -10001)
D2FUNCPTR(FOG, FreePoolMemory, DWORD __fastcall, (DWORD handle, LPCSTR lpFile, DWORD flag, DWORD u1), -10043); // same in 1.10 and 1.11
D2FUNCPTR(D2WIN, CreateFont, DWORD __fastcall, (LPCSTR lpFontPath, DWORD u1), -10081)
D2FUNCPTR(D2WIN, FreeFontHandle, void __fastcall, (DWORD handle), -10158)
//!!! check check: this ptr == eax == lpText, other arguments pushed to the stack. (__thiscall)
D2FUNCPTR(D2WIN, DrawText2_I, DWORD __fastcall, (LPWSTR lpText, int x, int y, DWORD u1, int nColor, DWORD u2), DLLBASE_D2WIN+0xEE80)
//!!! check check: this ptr == eax == lpText, other arguments pushed to the stack. (__thiscall)
D2FUNCPTR(D2WIN, InitializeFontTable_I, DWORD __fastcall, (LPSTR lpText, DWORD line, LPCSTR file), DLLBASE_D2WIN+0x7C20)
//!!! check check: this ptr == ecx == lpText, other arguments pushed to the stack. (__thiscall)
D2FUNCPTR(D2WIN, InitializeFont_I, DWORD __fastcall, (LPSTR lpText, DWORD dwSize), DLLBASE_D2WIN+0xE890)
//!!! check check: this ptr == esi == hWnd, other arguments pushed to the stack. (__thiscall)
D2FUNCPTR(D2WIN, FontStuff_1_I, void __fastcall, (D2EditBox *hWnd), DLLBASE_D2WIN+0x10000)
//!!! check check: this ptr == eax == hWnd, other arguments pushed to the stack. (__thiscall)
D2FUNCPTR(D2WIN, FontStuff_2_I, DWORD __fastcall, (D2EditBox *hWnd, DWORD bKeyCode), DLLBASE_D2WIN+0x11400)
D2VARPTR(D2WIN, FontTable, FontInfo_t, DLLBASE_D2WIN+0x204E8);
D2VARPTR(D2WIN, CurrentFont, DWORD, DLLBASE_D2WIN+0x1ED14);
D2FUNCPTR(STORM, OpenArchive, BOOL __stdcall, (LPCSTR filename, DWORD flag1, DWORD flag2, PHANDLE phArchive), -266)
D2FUNCPTR(STORM, CloseArchive, void __stdcall, (HANDLE phArchive), -252)
D2VARPTR(BNCLIENT, ChatMessage, LPDWORD, DLLBASE_BNCLIENT+0x1D854)

D2ASMPTR(D2CLIENT, D2EndOfPtr, 0xeeeeeeee)

#define D2CLIENT_InitAutomapLayer(layerlvl)	((AutomapLayer*)D2CLIENT_InitAutomapLayer_STUB(layerlvl))
#define D2CLIENT_SetAutomapParty	D2CLIENT_SetAutomapParty_STUB
#define D2CLIENT_SetAutomapNames	D2CLIENT_SetAutomapNames_STUB
#define D2CLIENT_GetMonsterTxt(mon)	((MonsterTxt *)D2CLIENT_GetMonsterTxt_STUB(mon))
#define D2CLIENT_TestPvpFlag		D2CLIENT_TestPvpFlag_STUB
#define D2CLIENT_GetUnitFromId(unitid, unittype)		((UnitAny *)D2CLIENT_GetUnitFromId_STUB(unitid, unittype))
#define D2CLIENT_GetInventoryId		D2CLIENT_GetInventoryId_STUB
#define D2CLIENT_GetUiVar			D2CLIENT_GetUiVar_STUB
#define D2WIN_DrawText2				D2WIN_DrawText2_STUB
#define D2WIN_InitializeFontTable	D2WIN_InitializeFontTable_STUB
#define D2WIN_InitializeFont		D2WIN_InitializeFont_STUB
#define D2WIN_FontStuff_1			D2WIN_FontStuff_1_STUB
#define D2WIN_FontStuff_2			D2WIN_FontStuff_2_STUB

/*
// exist but not use
D2FUNCPTR(D2COMMON, GetObjgroupTxt, ObjgroupTxt * __stdcall, (DWORD objno), -0x2983)
// end

// not found yet
//D2FUNCPTR(D2WIN, GetTextWidth, int __fastcall, (wchar_t *str), 0x6F8AC7C0)
// end

// not exist in 1.10
D2ASMPTR(D2CLIENT, DrawItemBlobPatch_ORIG, 0x6FAC84B9)
// end

// replace by other stuff
D2FUNCPTR(D2COMMON, GetMonsterTxt, MonsterTxt * __stdcall, (DWORD monno), -0x2956)
D2VARPTR(D2COMMON, aTreasureClasses, TreasureClass *, 0x6FDE1C14)
// end
*/

#define pD2PtrsListEnd D2CLIENT_D2EndOfPtr

#define D2CLIENT_pDrlgAct (*p_D2CLIENT_pDrlgAct)
#define D2CLIENT_PlayerUnit (*p_D2CLIENT_PlayerUnit)
#define D2CLIENT_GetPlayerUnit() D2CLIENT_PlayerUnit

#define D2CLIENT_pAutomapLayer (*p_D2CLIENT_pAutomapLayer)
#define D2CLIENT_pAutomapLayerListHdr (*p_D2CLIENT_pAutomapLayerListHdr)
#define D2CLIENT_fAutomapOn (*p_D2CLIENT_fAutomapOn)
#define D2CLIENT_ptAutomap (*p_D2CLIENT_ptAutomap)
#define D2CLIENT_ptOffset (*p_D2CLIENT_ptOffset)

#define D2CLIENT_xMapShake (*p_D2CLIENT_xMapShake)
#define D2CLIENT_yMapShake (*p_D2CLIENT_yMapShake)

#define D2COMMON_nWeaponsTxt (*p_D2COMMON_nWeaponsTxt)
#define D2COMMON_nArmorTxt (*p_D2COMMON_nArmorTxt)

#define D2CLIENT_nQuestPage (*p_D2CLIENT_nQuestPage)
#define D2CLIENT_fExitAppFlag (*p_D2CLIENT_fExitAppFlag)

#define D2COMMON_aTreasureClasses (*p_D2COMMON_aTreasureClasses)
#define D2CLIENT_nTextLength (*p_D2CLIENT_nTextLength)
#define D2CLIENT_yPosition (*p_D2CLIENT_yPosition)
#define D2CLIENT_pInSocketablePatch (*p_D2CLIENT_pInSocketablePatch)
#define D2CLIENT_nPtDivisor (*p_D2CLIENT_nPtDivisor)
#define D2WIN_pFocusedControl (*p_D2WIN_pFocusedControl)
#define D2NET_Socket (*p_D2NET_Socket)
#define D2WIN_FontTable (p_D2WIN_FontTable)
#define D2WIN_CurrentFont (*p_D2WIN_CurrentFont)

#define D2CLIENT_pWardenInterface (*p_D2CLIENT_pWardenInterface)
