#include "stdafx.h"

#define VARIABLE_DEFINE
#include "Module.h"
#undef VARIABLE_DEFINE

