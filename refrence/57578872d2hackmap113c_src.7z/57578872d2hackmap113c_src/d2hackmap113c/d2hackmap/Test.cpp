#include "stdafx.h"

#ifdef MODULE_TEST


void ShowTestInfo(){

	DrlgAct *pR = ACT;
	
}



#endif