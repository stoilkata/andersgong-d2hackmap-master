
#ifdef PATH_INSTALL

};
#endif
#ifdef PATH_INSTALL2
};
#endif
#ifdef CONFIG_LOAD

};
#endif


#ifdef VARIABLE_DEFINE

#undef GVAR
#undef GVAR2

#endif

