//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res_sc.rc
//
#define IDI_TRAY_ICON                   1
#define IDR_MENU1                       101
#define IDR_TRAYMENU                    101
#define IDD_ABOUT                       103
#define IDD_PROPERTIES                  105
#define IDI_ICON1                       108
#define IDI_OK                          112
#define IDB_BACKGROUND                  116
#define IDI_DIABLOII2                   118
#define IDI_DIABLOII                    118
#define IDI_ABOUTME                     121
#define IDI_INSTALL                     122
#define IDI_UNLOAD                      125
#define IDI_EXIT                        126
#define IDI_STING                       127
#define IDI_PORTRAIT                    127
#define IDI_EDITCONFIG                  128
#define IDI_DLL                         129
#define IDI_REVEALACT                   131
#define IDI_ISCAN                       132
#define IDC_EDIT_USERNAME               1000
#define IDC_EDIT_PASSWORD               1001
#define IDC_EDIT_APPLICATION_NAME       1002
#define IDC_EDIT_CMD_LINE               1003
#define IDC_CHECK_RESTRICTED_MODE       1004
#define IDC_BTN_INSTALL_SERVICE         1005
#define IDC_BTN_REMOVE_SERVICE          1006
#define IDC_BTN_INSTALL                 1007
#define IDC_BTN_REMOVE                  1008
#define IDC_BTN_ABOUT                   1009
#define IDC_BTN_EDITCONFIG              1010
#define IDS_TRAY_ICON                   1011
#define IDC_LIST_PROCESS                1012
#define IDS_TIP_LISTIVEW                1012
#define IDS_ERR_SELECT_GAME_FIRST       1013
#define IDC_BTN_REVEAL_ACT              1013
#define IDC_LIST_INTEGRITYSCAN          1013
#define IDC_CHECK_AUTOLOAD              1014
#define IDS_ERR_MODULE_NOTFOUND         1014
#define IDC_BTN_UPGRADECONFIG           1036
#define IDC_STATUS_BAR                  1015
#define IDS_ERR_GETMODULEHANDLE         1015
#define IDC_LIST_MODULES                1016
#define IDS_ERR_OS_NOTSUPPORT           1016
#define IDC_TAB_VIEW                    1017
#define IDS_ERR_CANNT_CREATE_FOR_PROCESS 1017
#define IDC_BTN_EXIT                    1018
#define IDS_ERR_CANNT_FIND              1019
#define IDC_CUSTOM1                     1019
#define IDS_ERROR_FILE_NOTEXISTS        1020
#define IDC_STATIC_ABOUT                1020
#define IDS_LOAD_SUCCESS                1021
#define IDS_LOAD_FAIL                   1022
#define IDS_READY                       1023
#define IDS_WRN_UNLOAD_DLL              1024
#define IDS_WRN_LOAD_DLL                1025
#define IDS_LANG_IDS                    1026
#define IDS_VERSION_INFO                1027
#define IDI_REVEAL_ACT                  1028
#define IDC_BTN_REVEAL_AUTOMAP_ACT      1028
#define IDS_ERR_MUST_INGAME             1029
#define IDS_WRN_UNPATCH_MODULE          1030
#define IDS_WRN_ISCAN_FAILED            1031
#define IDS_WRN_INTEGRITY_BROKEN        1032
#define IDS_LOADHACKMAP                 1033
#define IDS_UPDATEHACKMAP               1034
#define IDS_WRN_UPGRADE_CONFIG          1035
#define IDI_ABOUT                       40001
#define ID_ABOUT                        40001
#define ID_PROPERTIES                   40002
#define ID_CLOSE                        40003
#define ID_D2MENU_LOADHACKMAPMANUALLY   40005
#define ID_D2MENU_UNLOADHACKMAP         40006
#define ID_D2MENU_LOADOTHERMODULE       40007
#define ID_DLLMENU_UNLOADDLL            40008
#define ID_ISCNMENU_RESTORE             40009
#define ID_ISCANMENU_SCANNOW            40010
#define ID_DESKTOP_1                    50000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
