#ifndef __WIN_MAIN_
#define __WIN_MAIN_

#include <Windows.h>
#include <tchar.h>
#include "resource.h"


#endif // __WIN_MAIN_
